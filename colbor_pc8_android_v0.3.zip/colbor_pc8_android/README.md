# COLBOR PC8 Controller (Android, Java, zero dependencies)

Open this folder in Android Studio (Ladybug or newer, JDK 17) and let Gradle sync. Wrapper is Gradle 8.9, AGP 8.7.3, compileSdk 35, minSdk 26.

## App controls
One screen, two modes (switch at the top):
- **Ambient**: brightness, color temperature (2500-9000K) and Tungsten / Daylight / Shade presets.
- **Colored**: brightness, hue, saturation, and one-tap effects (tap to start, tap again to stop).
- A live preview card shows the current look. Power is pinned at the bottom.
- Control starts automatically on the first command. Tap the pill at the top right to find and pair a light; "Unpair light" appears once paired. With no light paired, commands go to all nearby lights.

Developer-only protocol controls and BLE diagnostics are not shown in the end-user interface.

## Protocol tests (JDK only)
    mkdir -p build-protocol
    javac -d build-protocol app/src/main/java/com/example/colbor/protocol/Target.java app/src/main/java/com/example/colbor/protocol/ColborProtocol.java protocol-tests/OracleTest.java
    java -cp build-protocol OracleTest

## Unverified on hardware
Power on/off meaning, HSI hue/saturation scaling, telemetry byte layout, and whether the lights need the phone's Bluetooth name to be "COLBOR" (this app does not rename the adapter). Test brightness/CCT first.
