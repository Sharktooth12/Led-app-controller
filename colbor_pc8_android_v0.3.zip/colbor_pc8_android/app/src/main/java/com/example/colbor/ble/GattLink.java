package com.example.colbor.ble;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;

/** Plain GATT connection to one device, reporting state and the discovered service table. Main-thread API. */
@SuppressLint("MissingPermission")
public final class GattLink {
    public interface Listener { void onMessage(String message); }

    private static final long CONNECT_TIMEOUT_MS = 15000;
    private final Context context;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private BluetoothGatt gatt;
    private Listener listener;
    private boolean connected;
    private final Runnable timeout = new Runnable() {
        @Override public void run() { if (!connected) { say("Timed out after 15 s. The device did not accept a connection (it may be broadcast-only, out of range, or already connected elsewhere)."); disconnect(); } }
    };

    public GattLink(Context c) { context = c.getApplicationContext(); }
    public boolean isActive() { return gatt != null; }

    public void connect(String mac, Listener l) {
        disconnect();
        listener = l;
        BluetoothManager bm = (BluetoothManager) context.getSystemService(Context.BLUETOOTH_SERVICE);
        BluetoothAdapter a = bm == null ? null : bm.getAdapter();
        if (a == null || !a.isEnabled()) throw new IllegalStateException("Bluetooth is unavailable or disabled");
        BluetoothDevice d = a.getRemoteDevice(mac);
        say("Connecting to " + mac + " ...");
        handler.postDelayed(timeout, CONNECT_TIMEOUT_MS);
        gatt = d.connectGatt(context, false, callback, BluetoothDevice.TRANSPORT_LE);
        if (gatt == null) { handler.removeCallbacks(timeout); say("connectGatt returned null"); }
    }

    public void disconnect() {
        handler.removeCallbacks(timeout);
        connected = false;
        BluetoothGatt g = gatt; gatt = null;
        if (g != null) { try { g.disconnect(); g.close(); } catch (RuntimeException ignored) {} }
    }

    private void say(final String m) {
        handler.post(new Runnable() { @Override public void run() { if (listener != null) listener.onMessage(m); } });
    }

    private final BluetoothGattCallback callback = new BluetoothGattCallback() {
        @Override public void onConnectionStateChange(BluetoothGatt g, int status, int newState) {
            if (newState == BluetoothProfile.STATE_CONNECTED && status == BluetoothGatt.GATT_SUCCESS) {
                handler.post(new Runnable() { @Override public void run() { handler.removeCallbacks(timeout); connected = true; } });
                say("Connected. Discovering services ...");
                g.discoverServices();
            } else {
                final String m = "Disconnected / failed: " + describe(status);
                handler.post(new Runnable() { @Override public void run() { disconnect(); } });
                say(m);
            }
        }
        @Override public void onServicesDiscovered(BluetoothGatt g, int status) {
            if (status != BluetoothGatt.GATT_SUCCESS) { say("Service discovery failed: " + describe(status)); return; }
            StringBuilder sb = new StringBuilder("Connected. Services:\n");
            for (BluetoothGattService s : g.getServices()) {
                sb.append(s.getUuid()).append('\n');
                for (BluetoothGattCharacteristic c : s.getCharacteristics())
                    sb.append("  ").append(c.getUuid()).append("  ").append(props(c.getProperties())).append('\n');
            }
            if (g.getServices().isEmpty()) sb.append("(none)");
            say(sb.toString().trim());
        }
    };

    private static String props(int p) {
        StringBuilder sb = new StringBuilder();
        if ((p & BluetoothGattCharacteristic.PROPERTY_READ) != 0) sb.append("R");
        if ((p & BluetoothGattCharacteristic.PROPERTY_WRITE) != 0) sb.append("W");
        if ((p & BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0) sb.append("w");
        if ((p & BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0) sb.append("N");
        if ((p & BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0) sb.append("I");
        return "[" + sb + "]";
    }

    private static String describe(int status) {
        switch (status) {
            case 0: return "link closed by device (status 0)";
            case 8: return "connection timeout (status 8)";
            case 19: return "device terminated the connection (status 19)";
            case 22: return "phone terminated the connection (status 22)";
            case 62: return "connection failed to establish (status 62)";
            case 133: return "generic GATT error 133 (device not connectable, out of range, or busy; retry after toggling Bluetooth)";
            default: return "status " + status;
        }
    }
}
