package com.example.colbor.protocol;

/** Broadcast destination encoded into each command header. */
public final class Target {
    public enum Kind { ALL, GROUP, SINGLE }
    public final Kind kind;
    public final int id;
    private Target(Kind kind, int id) { this.kind = kind; this.id = id & 0xFFFF; }
    public static Target all() { return new Target(Kind.ALL, 0xFFFF); }
    public static Target group(int id) { return new Target(Kind.GROUP, id); }
    public static Target single(int address) { return new Target(Kind.SINGLE, address); }
    String addressHex() { return String.format(java.util.Locale.ROOT, "%04X", id); }
}
