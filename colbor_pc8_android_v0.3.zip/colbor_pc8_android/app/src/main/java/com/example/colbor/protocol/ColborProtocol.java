package com.example.colbor.protocol;

import java.util.Locale;
import java.util.Random;

/** COLBOR advertisement-command frame encoder, derived from the supplied handoff. */
public final class ColborProtocol {
    public interface ByteSource { int nextByte(); }
    private final ByteSource random;
    public ColborProtocol() { final Random r = new Random(); random = new ByteSource() { public int nextByte() { return r.nextInt(256); } }; }
    public ColborProtocol(final int fixedRandomByte) { random = new ByteSource() { public int nextByte() { return fixedRandomByte & 255; } }; }
    public ColborProtocol(ByteSource random) { if (random == null) throw new IllegalArgumentException("random is null"); this.random = random; }

    public String power(Target target, int scene, boolean on) { return control(target, scene, on ? "02" : "01", "0102"); }
    public String brightness(Target target, int scene, int percent) {
        if (percent < 0 || percent > 100) throw new IllegalArgumentException("brightness must be 0..100");
        return control(target, scene, hex4(percent * 10), "0602");
    }
    public String cct(Target target, int scene, int kelvin) {
        if (kelvin < 1000 || kelvin > 20000) throw new IllegalArgumentException("CCT out of range");
        return control(target, scene, hex4(kelvin), "0302");
    }
    public String cctBrightness(Target target, int scene, int percent, int kelvin) {
        if (percent < 0 || percent > 100) throw new IllegalArgumentException("brightness must be 0..100");
        return control(target, scene, hex4(percent * 10) + hex4(kelvin), "0C02");
    }
    public String hsi(Target target, int scene, int percent, int saturation, int hue) {
        if (percent < 0 || percent > 100 || saturation < 0 || saturation > 255 || hue < 0 || hue > 65535) throw new IllegalArgumentException("HSI value out of range");
        return control(target, scene, hex4(percent * 10) + hex2(saturation) + hex4(hue), "0702");
    }
    public String hue(Target t, int s, int v) { return control(t,s,hex2(byteValue(v)),"0402"); }
    public String saturation(Target t, int s, int v) { return control(t,s,hex2(byteValue(v)),"0502"); }
    public String gm(Target t, int s, int v) { return control(t,s,hex2(byteValue(v)),"1102"); }
    public String fanMode(Target t, int s, int v) { return control(t,s,hex2(byteValue(v)),"0902"); }
    public String paramRandom(Target t, int s, int v) { return control(t,s,hex2(byteValue(v)),"1302"); }
    public String rawControl(Target t, int scene, String payloadHex, String commandCode) { return control(t,scene,cleanHex(payloadHex),cleanCode(commandCode)); }

    /** Parameters are supplied in UI order and encoded in reverse order, one byte each. */
    public String effect(Target t, int scene, int... parameters) {
        StringBuilder payload = new StringBuilder();
        for (int i=parameters.length-1; i>=0; i--) payload.append(hex2(byteValue(parameters[i])));
        return control(t, scene, payload.toString(), "0202");
    }
    public String join(Target target, int destinationScene, boolean force) {
        return management(target, 0, hex4(destinationScene) + (force ? "05" : "01"));
    }
    public String leave(Target singleTarget, int currentScene) {
        if (singleTarget.kind != Target.Kind.SINGLE) throw new IllegalArgumentException("leave requires SINGLE target");
        return frame("02", "", singleTarget, currentScene, "13");
    }
    public String group(Target target, int currentScene, int groupId, boolean add) {
        return management(target, currentScene, hex4(groupId) + (add ? "03" : "04"));
    }
    private String management(Target target, int scene, String payload) { return frame(payload, "", target, scene, "13"); }
    private String control(Target target, int scene, String payload, String code) { return frame(payload, code, target, scene, "33"); }

    private String frame(String payload, String code, Target target, int scene, String type) {
        payload = cleanHex(payload); code = code == null || code.length() == 0 ? "" : cleanCode(code);
        String addr = target.addressHex();
        String scope = target.kind == Target.Kind.SINGLE ? "03" : "83";
        String rr = hex2(random.nextByte());
        String header = addr + type + scope + rr + hex4(scene);
        String beforeLength = payload + code + header;
        if ((beforeLength.length() & 1) != 0) throw new IllegalArgumentException("frame body must contain whole bytes");
        String body = beforeLength + hex2(beforeLength.length()/2) + "1E";
        if (body.length() > 32) throw new IllegalArgumentException("frame exceeds 128 bits");
        while (body.length() < 32) body = "0" + body;
        String uuid = body.substring(0,8)+"-"+body.substring(8,12)+"-"+body.substring(12,16)+"-"+body.substring(16,20)+"-"+body.substring(20,32);
        return uuid.toUpperCase(Locale.ROOT);
    }
    private static int byteValue(int n) { if(n<0||n>255) throw new IllegalArgumentException("value must be 0..255"); return n; }
    private static String hex2(int n) { return String.format(Locale.ROOT,"%02X",n & 255); }
    private static String hex4(int n) { if(n<0||n>65535) throw new IllegalArgumentException("value must be 0..65535"); return String.format(Locale.ROOT,"%04X",n); }
    private static String cleanHex(String s) { if(s==null) throw new IllegalArgumentException("hex is null"); String x=s.replace(" ","").toUpperCase(Locale.ROOT); if(!x.matches("[0-9A-F]*") || (x.length()&1)!=0) throw new IllegalArgumentException("invalid hex: "+s); return x; }
    private static String cleanCode(String s) { String x=cleanHex(s); if(x.length()!=4) throw new IllegalArgumentException("command code must be 2 bytes"); return x; }
}
