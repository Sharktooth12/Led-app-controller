package com.example.colbor.ble;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanRecord;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.util.SparseArray;
import com.example.colbor.protocol.Telemetry;
import java.util.ArrayList;

/** Unfiltered BLE scan. Each result is offered to the telemetry parser. */
@SuppressLint("MissingPermission")
public final class Scanner {
    public interface Listener {
        /** telemetry is null when the advertisement is not recognised as a COLBOR status packet. */
        void onResult(String deviceAddress, String name, int rssi, Telemetry telemetry, String raw);
        void onError(int errorCode);
    }

    private final Context context;
    private BluetoothLeScanner scanner;
    private ScanCallback callback;

    public Scanner(Context c) { context = c.getApplicationContext(); }
    public boolean isRunning() { return callback != null; }

    public void start(final Listener listener) {
        if (callback != null) return;
        BluetoothManager bm = (BluetoothManager) context.getSystemService(Context.BLUETOOTH_SERVICE);
        BluetoothAdapter a = bm == null ? null : bm.getAdapter();
        if (a == null || !a.isEnabled()) throw new IllegalStateException("Bluetooth is unavailable or disabled");
        scanner = a.getBluetoothLeScanner();
        if (scanner == null) throw new IllegalStateException("BLE scanning is unavailable");
        ScanSettings settings = new ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).setCallbackType(ScanSettings.CALLBACK_TYPE_ALL_MATCHES).build();
        callback = new ScanCallback() {
            @Override public void onScanResult(int type, ScanResult r) {
                Telemetry t = null;
                ScanRecord rec = r.getScanRecord();
                if (rec != null) {
                    SparseArray<byte[]> m = rec.getManufacturerSpecificData();
                    for (int i = 0; i < m.size() && t == null; i++) {
                        try { t = Telemetry.parse(m.valueAt(i)); } catch (RuntimeException ignored) {}
                    }
                }
                String name = rec == null ? null : rec.getDeviceName();
                if (listener != null) listener.onResult(r.getDevice().getAddress(), name, r.getRssi(), t, describe(rec));
            }
            @Override public void onScanFailed(int error) { callback = null; if (listener != null) listener.onError(error); }
        };
        scanner.startScan(new ArrayList<android.bluetooth.le.ScanFilter>(), settings, callback);
    }

    /** Human-readable dump of manufacturer data and service UUIDs, for diagnosing unknown packets. */
    private static String describe(ScanRecord rec) {
        if (rec == null) return "(no scan record)";
        StringBuilder sb = new StringBuilder();
        SparseArray<byte[]> m = rec.getManufacturerSpecificData();
        for (int i = 0; i < m.size(); i++) {
            sb.append(String.format(java.util.Locale.ROOT, "mfr %04X: ", m.keyAt(i)));
            for (byte b : m.valueAt(i)) sb.append(String.format(java.util.Locale.ROOT, "%02X", b & 0xFF));
            sb.append('\n');
        }
        if (rec.getServiceUuids() != null) sb.append("uuids: ").append(rec.getServiceUuids()).append('\n');
        if (sb.length() == 0) sb.append("(no manufacturer data or service UUIDs)");
        return sb.toString().trim();
    }

    public void stop() {
        try { if (scanner != null && callback != null) scanner.stopScan(callback); } catch (RuntimeException ignored) {}
        callback = null;
    }
}
