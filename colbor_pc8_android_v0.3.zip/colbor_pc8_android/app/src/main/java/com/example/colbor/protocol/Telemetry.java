package com.example.colbor.protocol;

/** Decodes the manufacturer data payload after its company identifier. */
public final class Telemetry {
    public final int networkId, packetType, address, groupId, modelId, productStatus, colorCount, battery;
    public final int effectName, effectRate, mode, hue, saturation, brightnessPercent, cctKelvin;
    public final Integer hardware, firmware;
    private Telemetry(byte[] d) {
        networkId=u16le(d,0); packetType=(d[4] & 0xFF) >>> 4;
        address=((d[6]&255)<<8)|(d[5]&255); groupId=u16le(d,8); modelId=u16le(d,10);
        productStatus=(d[12]&255)>>>4; colorCount=d[12]&15; battery=d[13]&255;
        effectName=d[14]&255; effectRate=d[15]&255; mode=d[16]&255;
        hue=u16le(d,17); saturation=d[19]&255; brightnessPercent=u16le(d,20)/10; cctKelvin=u16le(d,22);
        hardware=d.length>24?Integer.valueOf(d[24]&255):null; firmware=d.length>25?Integer.valueOf(d[25]&255):null;
    }
    public static Telemetry parse(byte[] d) {
        if(d==null || d.length<24 || (d[7]&255)!=1) return null;
        return new Telemetry(d);
    }
    private static int u16le(byte[] d,int i) { return (d[i]&255)|((d[i+1]&255)<<8); }
}
