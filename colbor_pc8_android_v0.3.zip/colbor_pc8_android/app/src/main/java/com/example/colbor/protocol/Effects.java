package com.example.colbor.protocol;

public final class Effects {
    public static final int STOP=0, FIRE=3, PULSING=4, FAULTY_BULB=5, STROBE=6, LIGHTNING=7,
        FIREWORKS=9, TV=10, PARTY=11, BEACON=12, WELDING=13, EXPLOSION=14, SOS=15, CCT_CHASE=19;
    public static final int RED_WHITE=1, BLUE_WHITE=2, RED_BLUE=3, RED_BLUE_WHITE=4;
    private Effects() {}
    public static int[] stop() { return new int[]{0,0,0}; }
    public static int[] normal(int effectId,int rateZeroToFour,boolean randomPreset) {
        if(rateZeroToFour<0||rateZeroToFour>4) throw new IllegalArgumentException("rate must be 0..4");
        return randomPreset ? new int[]{effectId,rateZeroToFour+1,0,3} : new int[]{effectId,rateZeroToFour+1,0};
    }
    public static int[] beacon(int levelZeroToFour,int policeType) {
        if(levelZeroToFour<0||levelZeroToFour>4||policeType<1||policeType>4) throw new IllegalArgumentException("invalid beacon values");
        return new int[]{BEACON,levelZeroToFour+1,policeType};
    }
}
