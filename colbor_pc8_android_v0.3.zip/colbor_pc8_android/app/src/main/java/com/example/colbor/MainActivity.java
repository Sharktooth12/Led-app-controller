package com.example.colbor;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.colbor.ble.Scanner;
import com.example.colbor.ble.Transmitter;
import com.example.colbor.protocol.ColborProtocol;
import com.example.colbor.protocol.Effects;
import com.example.colbor.protocol.Models;
import com.example.colbor.protocol.Target;
import com.example.colbor.protocol.Telemetry;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Single-screen, dependency-free COLBOR light controller: Ambient (white) and Colored (hue + effects). */
public final class MainActivity extends Activity {
    private interface Cmd { String make() throws Exception; }
    private interface IntCb { void run(int value); }
    private static final int DEFAULT_SCENE = 1;

    private static final class Slider {
        SeekBar bar; int min, step;
        int get() { return min + bar.getProgress() * step; }
        void set(int v) { bar.setProgress((v - min) / step); }
    }
    private static final class Entry { int rssi; Telemetry t; }

    private static final int PERMISSION_REQUEST = 71;
    private static final int BG = Color.rgb(15, 16, 19), CARD = Color.rgb(26, 28, 33), BTN = Color.rgb(42, 45, 52), OFF = Color.rgb(26, 28, 33);
    private static final int TEXT = Color.rgb(244, 242, 238), MUTED = Color.rgb(163, 167, 176), ACCENT = Color.rgb(255, 190, 70), INK = Color.rgb(22, 19, 13), ON_ACCENT = Color.rgb(26, 18, 4);

    private static final String[] EFFECT_NAMES = {"Fire", "Pulsing", "Strobe", "Lightning", "Fireworks", "TV", "Party", "SOS"};
    private static final int[] EFFECT_IDS = {Effects.FIRE, Effects.PULSING, Effects.STROBE, Effects.LIGHTNING, Effects.FIREWORKS, Effects.TV, Effects.PARTY, Effects.SOS};
    private static final int EFFECT_RATE = 2;
    private static final String[] PRESET_NAMES = {"Tungsten", "Daylight", "Shade"};
    private static final int[] PRESET_K = {3200, 5600, 7500};
    private static final int[][] CCT_STOPS = {{2500, 255, 157, 77}, {3200, 255, 190, 120}, {4500, 255, 224, 190}, {5600, 255, 244, 232}, {7000, 225, 232, 255}, {9000, 190, 212, 255}};

    private final ColborProtocol protocol = new ColborProtocol();
    private Transmitter tx;
    private Scanner scanner;
    private LinearLayout page, deviceList, glowCard, ambientCard, colorCard, tabBar;
    private TextView status, pairedLabel, dialogInfo, bigText, subText;
    private Button unpairBtn, dlgScanBtn, powerBtn, tabAmbient, tabColored;
    private final List<Button> presetChips = new ArrayList<Button>();
    private final List<Button> effectChips = new ArrayList<Button>();
    private GradientDrawable glowBg;
    private AlertDialog scanDialog;
    private String selectedAddr;
    private int pairedAddr = -1;
    private int currentScene = DEFAULT_SCENE;
    private int mode = 0;          // 0 = Ambient, 1 = Colored
    private int activeEffect = -1; // index into EFFECT_*, -1 = none
    private boolean lightOn = true;
    private Slider sBright, sCct, sHue, sSat;
    private final Map<String, Entry> devices = new LinkedHashMap<String, Entry>();
    private boolean renderPending;
    private final Runnable refreshDevices = new Runnable() { @Override public void run() { renderPending = false; renderDevices(); } };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
        restorePaired();
        if (needsPermissions()) requestPermissions(requiredPermissions(), PERMISSION_REQUEST);
        else setStatus("Ready. Adjust any control to start.");
    }

    // ------------------------------------------------------------------ UI

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG);
        root.setOnApplyWindowInsetsListener((v, ins) -> {
            v.setPadding(ins.getSystemWindowInsetLeft(), ins.getSystemWindowInsetTop(), ins.getSystemWindowInsetRight(), ins.getSystemWindowInsetBottom());
            return ins;
        });
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(20), dp(20), dp(20), dp(12));
        scroll.addView(page);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        // Header: title + status, and a pill that opens the light finder
        LinearLayout header = hrow();
        LinearLayout titles = new LinearLayout(this); titles.setOrientation(LinearLayout.VERTICAL);
        titles.addView(text("COLBOR PC8", 20, TEXT, true));
        status = text("", 13, MUTED, false); titles.addView(status);
        header.addView(titles, new LinearLayout.LayoutParams(0, -2, 1));
        pairedLabel = button("Find light", v -> showScanDialog());
        pairedLabel.setBackground(round(CARD, 999, 0));
        pairedLabel.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        header.addView(pairedLabel, new LinearLayout.LayoutParams(-2, dp(48)));
        page.addView(header, new LinearLayout.LayoutParams(-1, -2));

        // Live preview card
        glowCard = new LinearLayout(this);
        glowCard.setOrientation(LinearLayout.VERTICAL); glowCard.setGravity(Gravity.BOTTOM);
        glowCard.setPadding(dp(18), dp(18), dp(18), dp(18));
        glowBg = new GradientDrawable(); glowBg.setCornerRadius(dp(24)); glowCard.setBackground(glowBg);
        bigText = text("", 44, INK, true); bigText.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        subText = text("", 16, INK, false);
        glowCard.addView(bigText); glowCard.addView(subText);
        LinearLayout.LayoutParams glp = new LinearLayout.LayoutParams(-1, dp(150)); glp.topMargin = dp(14);
        page.addView(glowCard, glp);

        // Tabs
        tabBar = hrow();
        tabBar.setPadding(dp(4), dp(4), dp(4), dp(4)); tabBar.setBackground(round(CARD, 16, 0));
        tabAmbient = button("Ambient", v -> setMode(0));
        tabColored = button("Colored", v -> setMode(1));
        for (Button t : new Button[]{tabAmbient, tabColored}) {
            t.setTextSize(15); t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            tabBar.addView(t, new LinearLayout.LayoutParams(0, dp(48), 1));
        }
        add(page, tabBar, 12);

        // Shared brightness
        LinearLayout bright = card(null);
        sBright = slider(bright, "Brightness", 0, 100, 1, 70, " %", v -> refreshGlow(), v -> commitBrightness(v));

        // Ambient controls
        ambientCard = card(null);
        sCct = slider(ambientCard, "Color temperature", Models.PC8.minCct, Models.PC8.maxCct, Models.PC8.cctStep, 5200, " K",
            v -> { refreshGlow(); refreshPresets(); }, v -> send(() -> protocol.cct(target(), scene(), v)));
        LinearLayout presets = hrow();
        for (int i = 0; i < PRESET_K.length; i++) {
            final int k = PRESET_K[i];
            Button b = button(PRESET_NAMES[i] + "\n" + k + "K", v -> { sCct.set(k); send(() -> protocol.cct(target(), scene(), k)); });
            b.setTextSize(14); presetChips.add(b);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(64), 1);
            lp.leftMargin = dp(i == 0 ? 0 : 5); lp.rightMargin = dp(i == PRESET_K.length - 1 ? 0 : 5);
            presets.addView(b, lp);
        }
        add(ambientCard, presets, 8);

        // Colored controls
        colorCard = card(null);
        sHue = slider(colorCard, "Hue", 0, 360, 1, 28, " deg", v -> { refreshGlow(); }, v -> applyColor());
        View rainbow = new View(this);
        GradientDrawable rb = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
            new int[]{0xFFFF0000, 0xFFFFFF00, 0xFF00FF00, 0xFF00FFFF, 0xFF0000FF, 0xFFFF00FF, 0xFFFF0000});
        rb.setCornerRadius(dp(5)); rainbow.setBackground(rb);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(-1, dp(10)); rlp.topMargin = dp(4);
        colorCard.addView(rainbow, colorCard.indexOfChild(sHue.bar), rlp);
        sSat = slider(colorCard, "Saturation", 0, 100, 1, 80, " %", v -> refreshGlow(), v -> applyColor());
        colorCard.addView(text("Effects: tap to start, tap again to stop", 13, MUTED, false), lpTop(10));
        HorizontalScrollView hs = new HorizontalScrollView(this); hs.setHorizontalScrollBarEnabled(false);
        LinearLayout fxRow = hrow();
        for (int i = 0; i < EFFECT_NAMES.length; i++) {
            final int idx = i;
            Button b = button(EFFECT_NAMES[i], v -> toggleEffect(idx));
            b.setTextSize(14); b.setPadding(dp(16), 0, dp(16), 0); effectChips.add(b);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(48)); lp.rightMargin = dp(8);
            fxRow.addView(b, lp);
        }
        hs.addView(fxRow);
        add(colorCard, hs, 8);

        unpairBtn = button("Unpair light", v -> unpair());
        unpairBtn.setBackground(round(Color.TRANSPARENT, 14, 0)); unpairBtn.setTextColor(MUTED);
        add(page, unpairBtn, 8);

        // Power pinned at the bottom
        powerBtn = button("", v -> togglePower());
        powerBtn.setTextSize(18); powerBtn.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(-1, dp(60));
        plp.setMargins(dp(20), dp(4), dp(20), dp(16)); root.addView(powerBtn, plp);

        setContentView(root);
        styleTabs(); stylePower(); refreshPresets(); refreshEffects(); refreshGlow(); updatePairedLabel();
        ambientCard.setVisibility(View.VISIBLE); colorCard.setVisibility(View.GONE);
    }

    // ------------------------------------------------------------------ state -> UI

    private void setMode(int m) {
        if (mode == m) return;
        stopEffect();
        mode = m;
        ambientCard.setVisibility(m == 0 ? View.VISIBLE : View.GONE);
        colorCard.setVisibility(m == 1 ? View.VISIBLE : View.GONE);
        styleTabs(); refreshGlow();
        if (tx != null && tx.isRunning() && lightOn) { if (m == 0) applyAmbient(); else applyColor(); }
    }

    private void styleTabs() {
        styleTab(tabAmbient, mode == 0); styleTab(tabColored, mode == 1);
    }
    private void styleTab(Button t, boolean sel) {
        t.setBackground(round(sel ? ACCENT : Color.TRANSPARENT, 12, 0));
        t.setTextColor(sel ? ON_ACCENT : TEXT);
    }
    private void styleChip(Button b, boolean sel) {
        b.setBackground(round(CARD, 14, sel ? ACCENT : Color.TRANSPARENT));
        b.setTextColor(TEXT);
    }
    private void refreshPresets() {
        if (sCct == null) return;
        for (int i = 0; i < presetChips.size(); i++) styleChip(presetChips.get(i), sCct.get() == PRESET_K[i]);
    }
    private void refreshEffects() {
        for (int i = 0; i < effectChips.size(); i++) styleChip(effectChips.get(i), activeEffect == i);
    }
    private void stylePower() {
        powerBtn.setText(lightOn ? "Turn off" : "Turn on");
        powerBtn.setTextColor(lightOn ? TEXT : ON_ACCENT);
        powerBtn.setBackground(round(lightOn ? BTN : ACCENT, 18, 0));
    }

    private void refreshGlow() {
        if (glowBg == null || sBright == null || sCct == null || sHue == null || sSat == null) return;
        boolean amb = mode == 0;
        int b = sBright.get();
        int color; String big, sub; boolean dark;
        if (!lightOn) { color = OFF; big = "Off"; sub = "Light is off"; dark = false; }
        else if (amb) { color = ambientColor(sCct.get(), b); big = sCct.get() + "K"; sub = "Ambient white"; dark = b > 35; }
        else {
            float l = 15 + b * 0.4f;
            color = hsl(sHue.get(), sSat.get() / 100f, l / 100f);
            big = activeEffect >= 0 ? EFFECT_NAMES[activeEffect] : sHue.get() + "\u00B0";
            sub = activeEffect >= 0 ? "Effect running" : "Saturation " + sSat.get() + "%";
            dark = l >= 40;
        }
        glowBg.setColor(color);
        bigText.setText(big); subText.setText(sub);
        bigText.setTextColor(dark ? INK : TEXT); subText.setTextColor(dark ? INK : TEXT);
    }

    private static int ambientColor(int kelvin, int brightness) {
        int i = 1;
        while (i < CCT_STOPS.length - 1 && kelvin > CCT_STOPS[i][0]) i++;
        int[] a = CCT_STOPS[i - 1], c = CCT_STOPS[i];
        float t = Math.min(1f, Math.max(0f, (kelvin - a[0]) / (float) (c[0] - a[0])));
        float mix = 0.2f + 0.8f * brightness / 100f;
        int[] dark = {26, 28, 33}; int[] out = new int[3];
        for (int j = 0; j < 3; j++) {
            float target = a[j + 1] + (c[j + 1] - a[j + 1]) * t;
            out[j] = Math.round(dark[j] + (target - dark[j]) * mix);
        }
        return Color.rgb(out[0], out[1], out[2]);
    }

    private static int hsl(float hDeg, float s, float l) {
        float c = (1 - Math.abs(2 * l - 1)) * s, hp = (hDeg % 360f) / 60f;
        float x = c * (1 - Math.abs(hp % 2 - 1)), r = 0, g = 0, b = 0;
        if (hp < 1) { r = c; g = x; } else if (hp < 2) { r = x; g = c; } else if (hp < 3) { g = c; b = x; }
        else if (hp < 4) { g = x; b = c; } else if (hp < 5) { r = x; b = c; } else { r = c; b = x; }
        float m = l - c / 2;
        return Color.rgb(Math.round((r + m) * 255), Math.round((g + m) * 255), Math.round((b + m) * 255));
    }

    // ------------------------------------------------------------------ light commands

    private Target target() { return pairedAddr >= 0 ? Target.single(pairedAddr) : Target.all(); }
    private int scene() { return currentScene; }

    private void commitBrightness(int v) {
        if (!lightOn) { if (send(() -> protocol.power(target(), scene(), true))) { lightOn = true; stylePower(); refreshGlow(); } else return; }
        if (mode == 1 && activeEffect < 0) applyColor();
        else send(() -> protocol.brightness(target(), scene(), v));
    }
    private void applyAmbient() {
        send(() -> protocol.cct(target(), scene(), sCct.get()));
        send(() -> protocol.brightness(target(), scene(), sBright.get()));
    }
    private void applyColor() {
        if (activeEffect >= 0) { activeEffect = -1; refreshEffects(); refreshGlow(); }
        send(() -> protocol.hsi(target(), scene(), sBright.get(), sSat.get(), sHue.get()));
    }
    private void toggleEffect(int idx) {
        if (activeEffect == idx) { stopEffect(); return; }
        final int id = EFFECT_IDS[idx];
        if (send(() -> protocol.effect(target(), scene(), Effects.normal(id, EFFECT_RATE, false)))) {
            activeEffect = idx; lightOn = true; stylePower(); refreshEffects(); refreshGlow();
        }
    }
    private void stopEffect() {
        if (activeEffect < 0) return;
        activeEffect = -1; refreshEffects(); refreshGlow();
        send(() -> protocol.effect(target(), scene(), Effects.stop()));
    }
    private void togglePower() {
        final boolean next = !lightOn;
        boolean ok = send(() -> protocol.power(target(), scene(), next));
        if (ok && next) ok = send(() -> protocol.brightness(target(), scene(), sBright.get()));
        if (!ok) return;
        lightOn = next; if (!next) { activeEffect = -1; refreshEffects(); }
        stylePower(); refreshGlow();
    }

    // ------------------------------------------------------------------ BLE actions

    /** Starts advertising on first use so there is no separate "start control" step. */
    private boolean ensureStarted() {
        try {
            if (tx != null && tx.isRunning()) return true;
            if (!ensurePermissions()) return false;
            if (tx == null) {
                tx = new Transmitter(this);
                tx.setFailureListener((code, msg) -> runOnUiThread(() -> setStatus("Bluetooth error: " + msg)));
            }
            tx.start();
            return tx.isRunning();
        } catch (Exception e) { showError(e); return false; }
    }

    private boolean send(Cmd cmd) {
        try {
            if (!ensureStarted()) return false;
            tx.send(cmd.make());
            setStatus(pairedAddr >= 0 ? "Light updated." : "Sent to all nearby lights.");
            return true;
        } catch (Exception e) { showError(e); return false; }
    }

    // ------------------------------------------------------------------ scan / pair

    private void showScanDialog() {
        if (scanDialog != null) return;
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(16), dp(16), dp(16), dp(12)); root.setBackgroundColor(CARD);
        root.addView(text("FIND YOUR LIGHT", 12, ACCENT, true));
        dialogInfo = text("Searching for nearby COLBOR lights...", 12, MUTED, false); add(root, dialogInfo, 4);
        ScrollView sv = new ScrollView(this);
        deviceList = new LinearLayout(this); deviceList.setOrientation(LinearLayout.VERTICAL); sv.addView(deviceList);
        LinearLayout.LayoutParams svLp = new LinearLayout.LayoutParams(-1, dp(320)); svLp.topMargin = dp(8); root.addView(sv, svLp);
        dlgScanBtn = button("Scan", v -> { if (scanner != null && scanner.isRunning()) stopScan(); else startScan(); });
        buttons(root, dlgScanBtn, button("Pair", v -> pairSelected()));
        buttons(root, button("Close", v -> { if (scanDialog != null) scanDialog.dismiss(); }));
        ScrollView outer = new ScrollView(this); outer.setBackgroundColor(CARD); outer.addView(root);
        scanDialog = new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert).setView(outer).create();
        scanDialog.setOnDismissListener(d -> { stopScan(); scanDialog = null; deviceList = null; });
        scanDialog.show();
        startScan();
    }

    private void startScan() {
        try {
            String problem = scanProblem();
            if (problem != null) { if (dialogInfo != null) dialogInfo.setText(problem); setStatus(problem); }
            if (needsPermissions()) { ensurePermissions(); return; }
            if (scanner == null) scanner = new Scanner(this);
            scanner.stop();
            devices.clear(); selectedAddr = null; renderPending = false; renderDevices();
            scanner.start(new Scanner.Listener() {
                @Override public void onResult(String addr, String name, int rssiDbm, Telemetry t, String raw) {
                    if (deviceList == null) return;
                    if (t == null) return;
                    Entry e = devices.get(addr);
                    if (e == null) { e = new Entry(); devices.put(addr, e); }
                    e.rssi = rssiDbm; e.t = t;
                    if (!renderPending) { renderPending = true; deviceList.postDelayed(refreshDevices, 300); }
                }
                @Override public void onError(int code) { stopScan(); String m = "Scan failed: " + scanError(code); if (dialogInfo != null) dialogInfo.setText(m); setStatus(m); }
            });
            if (dlgScanBtn != null) dlgScanBtn.setText("Stop scan");
            if (problem == null && dialogInfo != null) dialogInfo.setText("Searching for nearby COLBOR lights...");
            if (deviceList != null) deviceList.postDelayed(new Runnable() { @Override public void run() {
                if (scanner != null && scanner.isRunning() && devices.isEmpty() && dialogInfo != null)
                    dialogInfo.setText("No lights found yet. Check that Bluetooth and Location are on.");
            } }, 5000);
        } catch (Exception e) { showError(e); if (dialogInfo != null) dialogInfo.setText(String.valueOf(e.getMessage())); }
    }

    private static String scanError(int code) {
        switch (code) {
            case 1: return "already started";
            case 2: return "app registration failed (toggle Bluetooth off/on)";
            case 3: return "internal error";
            case 4: return "BLE scanning unsupported";
            case 5: return "out of hardware resources";
            case 6: return "scanning too frequently (Android allows 5 starts per 30 s; wait and retry)";
            default: return "code " + code;
        }
    }

    /** Returns a human-readable reason a scan would silently find nothing, or null. */
    private String scanProblem() {
        if (needsPermissions()) return "Bluetooth permission not granted. Allow it, then tap Scan.";
        LocationManager lm = (LocationManager) getSystemService(LOCATION_SERVICE);
        boolean on = lm != null && (lm.isProviderEnabled(LocationManager.GPS_PROVIDER) || lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER));
        if (!on) return "System Location is OFF. Turn it on (quick settings or Settings > Location); Android returns no BLE scan results without it.";
        return null;
    }

    private void stopScan() {
        if (scanner != null) scanner.stop();
        if (dlgScanBtn != null) dlgScanBtn.setText("Scan");
    }

    private void renderDevices() {
        if (deviceList == null) return;
        List<Map.Entry<String, Entry>> list = new ArrayList<Map.Entry<String, Entry>>(devices.entrySet());
        Collections.sort(list, new Comparator<Map.Entry<String, Entry>>() {
            @Override public int compare(Map.Entry<String, Entry> x, Map.Entry<String, Entry> y) {
                boolean lx = x.getValue().t != null, ly = y.getValue().t != null;
                if (lx != ly) return lx ? -1 : 1;
                return y.getValue().rssi - x.getValue().rssi;
            }
        });
        deviceList.removeAllViews();
        for (final Map.Entry<String, Entry> en : list) {
            Entry e = en.getValue();
            if (e.t == null) continue;
            if (deviceList.getChildCount() >= 200) continue;
            String line = String.format(Locale.ROOT, "COLBOR light  •  %d%% battery  •  %d dBm", e.t.battery, e.rssi);
            TextView row = text(line, 13, TEXT, true);
            row.setPadding(dp(8), dp(10), dp(8), dp(10));
            if (en.getKey().equals(selectedAddr)) row.setBackgroundColor(Color.rgb(70, 58, 28));
            row.setOnClickListener(v -> { selectedAddr = en.getKey(); renderDevices(); });
            deviceList.addView(row);
        }
        String problem = scanProblem();
        if (dialogInfo != null) {
            if (problem != null) dialogInfo.setText(problem);
            else if (deviceList.getChildCount() == 0) dialogInfo.setText("Searching for nearby COLBOR lights...");
            else dialogInfo.setText("Select your light, then tap Pair.");
        }
    }

    private void pairSelected() {
        try {
            Entry e = selectedAddr == null ? null : devices.get(selectedAddr);
            if (e == null) throw new IllegalStateException("Select a device first");
            if (e.t == null) throw new IllegalStateException("Not a recognised COLBOR light (no status packet seen yet)");
            if (!ensureStarted()) return;
            final int addr = e.t.address, dest = DEFAULT_SCENE;
            send(() -> protocol.join(Target.single(addr), dest, false));
            pairedAddr = addr; currentScene = dest; savePaired(dest); updatePairedLabel();
            if (scanDialog != null) scanDialog.dismiss();
            setStatus("Light paired.");
        } catch (Exception ex) { showError(ex); }
    }

    private void unpair() {
        try {
            if (pairedAddr >= 0 && tx != null && tx.isRunning()) { final int a = pairedAddr; send(() -> protocol.leave(Target.single(a), scene())); }
            pairedAddr = -1; getSharedPreferences("colbor", MODE_PRIVATE).edit().clear().apply();
            updatePairedLabel();
        } catch (Exception ex) { showError(ex); }
    }

    private void savePaired(int scene) {
        getSharedPreferences("colbor", MODE_PRIVATE).edit().putInt("addr", pairedAddr).putInt("scene", scene).apply();
    }
    private void restorePaired() {
        SharedPreferences sp = getSharedPreferences("colbor", MODE_PRIVATE);
        if (!sp.contains("addr")) return;
        pairedAddr = sp.getInt("addr", -1);
        currentScene = sp.getInt("scene", DEFAULT_SCENE);
        updatePairedLabel();
    }
    private void updatePairedLabel() {
        pairedLabel.setText(pairedAddr >= 0 ? "Paired" : "Find light");
        unpairBtn.setVisibility(pairedAddr >= 0 ? View.VISIBLE : View.GONE);
    }

    // ------------------------------------------------------------------ permissions

    private String[] requiredPermissions() {
        if (Build.VERSION.SDK_INT >= 31) return new String[]{Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_ADVERTISE, Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION};
        return new String[]{Manifest.permission.ACCESS_FINE_LOCATION};
    }
    private boolean granted(String p) { return checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED; }
    /** Location counts as granted if either precise or approximate is allowed. */
    private boolean needsPermissions() {
        if (!granted(Manifest.permission.ACCESS_FINE_LOCATION) && !granted(Manifest.permission.ACCESS_COARSE_LOCATION)) return true;
        if (Build.VERSION.SDK_INT >= 31)
            return !granted(Manifest.permission.BLUETOOTH_SCAN) || !granted(Manifest.permission.BLUETOOTH_ADVERTISE) || !granted(Manifest.permission.BLUETOOTH_CONNECT);
        return false;
    }
    private boolean ensurePermissions() {
        if (!needsPermissions()) return true;
        requestPermissions(requiredPermissions(), PERMISSION_REQUEST);
        setStatus("Allow Nearby devices and Location, then try again.");
        return false;
    }
    @Override public void onRequestPermissionsResult(int request, String[] permissions, int[] grants) {
        super.onRequestPermissionsResult(request, permissions, grants);
        if (request != PERMISSION_REQUEST) return;
        boolean ok = !needsPermissions();
        setStatus(ok ? "Ready. Adjust any control to start." : "Bluetooth permissions are required.");
        if (ok && scanDialog != null) startScan();
    }

    @Override protected void onDestroy() {
        if (tx != null) tx.stop();
        if (scanner != null) scanner.stop();
        if (scanDialog != null) scanDialog.dismiss();
        super.onDestroy();
    }

    // ------------------------------------------------------------------ status / log

    private void setStatus(String m) { if (status != null) status.setText(m); }
    private void showError(Exception e) {
        String m = e instanceof NumberFormatException ? "Invalid number: " + e.getMessage() : (e.getMessage() == null ? e.toString() : e.getMessage());
        setStatus(m); Toast.makeText(this, m, Toast.LENGTH_LONG).show();
    }

    // ------------------------------------------------------------------ view helpers

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private GradientDrawable round(int fill, int radiusDp, int strokeColor) {
        GradientDrawable g = new GradientDrawable(); g.setColor(fill); g.setCornerRadius(dp(radiusDp));
        if (strokeColor != 0) g.setStroke(dp(2), strokeColor);
        return g;
    }
    private LinearLayout.LayoutParams lpTop(int topDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.topMargin = dp(topDp); return lp;
    }

    private LinearLayout card(String title) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL); c.setPadding(dp(16), dp(8), dp(16), dp(12));
        c.setBackground(round(CARD, 20, 0));
        page.addView(c, lpTop(12));
        if (title != null) c.addView(text(title, 12, ACCENT, true));
        return c;
    }
    private void add(LinearLayout parent, View v, int topDp) { parent.addView(v, lpTop(topDp)); }
    private LinearLayout hrow() { LinearLayout r = new LinearLayout(this); r.setOrientation(LinearLayout.HORIZONTAL); r.setGravity(Gravity.CENTER_VERTICAL); return r; }

    private TextView text(String value, float size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private Button button(String label, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label); b.setTextColor(TEXT); b.setAllCaps(false); b.setTextSize(14);
        b.setMinWidth(0); b.setMinHeight(0); b.setPadding(dp(14), dp(8), dp(14), dp(8));
        b.setBackground(round(BTN, 14, 0)); b.setStateListAnimator(null);
        b.setOnClickListener(l);
        return b;
    }
    private void buttons(LinearLayout parent, Button... bs) {
        LinearLayout r = hrow();
        for (int i = 0; i < bs.length; i++) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(48), 1);
            lp.leftMargin = dp(i == 0 ? 0 : 4); lp.rightMargin = dp(i == bs.length - 1 ? 0 : 4);
            r.addView(bs[i], lp);
        }
        add(parent, r, 8);
    }
    /** Slider with a live label: live runs on every change, commit runs when the finger lifts. */
    private Slider slider(LinearLayout parent, String label, final int min, int max, final int step, int init, final String unit, final IntCb live, final IntCb commit) {
        LinearLayout head = hrow();
        head.addView(text(label, 15, TEXT, true), new LinearLayout.LayoutParams(0, -2, 1));
        final TextView val = text(init + unit, 16, ACCENT, true); val.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        head.addView(val);
        add(parent, head, 6);
        final Slider s = new Slider(); s.min = min; s.step = step;
        s.bar = new SeekBar(this);
        s.bar.setMax((max - min) / step); s.bar.setProgress((init - min) / step);
        s.bar.setContentDescription(label);
        s.bar.setProgressTintList(ColorStateList.valueOf(ACCENT)); s.bar.setThumbTintList(ColorStateList.valueOf(ACCENT));
        s.bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar b, int p, boolean fromUser) { val.setText((min + p * step) + unit); if (live != null) live.run(s.get()); }
            @Override public void onStartTrackingTouch(SeekBar b) {}
            @Override public void onStopTrackingTouch(SeekBar b) { if (commit != null) commit.run(s.get()); }
        });
        parent.addView(s.bar, new LinearLayout.LayoutParams(-1, dp(44)));
        return s;
    }
}
