package com.example.colbor.protocol;

/** Known model presets from the supplied handoff; full 86-model table needs the stock APK asset. */
public final class Models {
    public static final class Model {
        public final int id, minCct, maxCct, cctStep;
        public final boolean hasBattery, hasGreenMagenta;
        public final String name;
        Model(int id,String name,int min,int max,int step,boolean battery,boolean gm) { this.id=id;this.name=name;minCct=min;maxCct=max;cctStep=step;hasBattery=battery;hasGreenMagenta=gm; }
    }
    public static final Model PC8 = new Model(30085,"COLBOR PC8",2500,9000,50,true,false);
    public static final int DEFAULT_MIN_CCT=2700, DEFAULT_MAX_CCT=6500, DEFAULT_CCT_STEP=50;
    private Models() {}
}
