package com.example.colbor.ble;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.AdvertiseCallback;
import android.bluetooth.le.AdvertiseData;
import android.bluetooth.le.AdvertiseSettings;
import android.bluetooth.le.BluetoothLeAdvertiser;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelUuid;
import java.util.ArrayDeque;
import java.util.Queue;
import java.util.UUID;

/** BLE command broadcaster. Main-thread API. Needs BLUETOOTH_ADVERTISE at runtime on Android 12+. */
@SuppressLint("MissingPermission")
public final class Transmitter {
    public interface FailureListener { void onFailure(int errorCode, String message); }

    private static final String IDLE_UUID = "00000000-0000-0000-0000-000000000000";

    private final Context context;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Queue<String> queue = new ArrayDeque<String>();
    private BluetoothLeAdvertiser advertiser;
    private AdvertiseCallback callback;
    private FailureListener failureListener;
    private long lastCommandAt;
    private boolean running, idleSent;

    // Tunable settings (applied to the next frame).
    private int advertiseMode = AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY;
    private int txPower = AdvertiseSettings.ADVERTISE_TX_POWER_HIGH;
    private boolean includeDeviceName = false;
    private long tickMs = 250, idleMs = 3500;
    private int queueLimit = 3;

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!running) return;
            String frame;
            synchronized (queue) { frame = queue.poll(); }
            if (frame != null) startFrame(frame);
            else if (!idleSent && System.currentTimeMillis() - lastCommandAt >= idleMs) { startFrame(IDLE_UUID); idleSent = true; }
            handler.postDelayed(this, tickMs);
        }
    };

    public Transmitter(Context c) { context = c.getApplicationContext(); }

    public void setFailureListener(FailureListener l) { failureListener = l; }
    public void configure(int advertiseMode, int txPower, boolean includeDeviceName, long tickMs, long idleMs, int queueLimit) {
        if (tickMs < 20 || idleMs < 0 || queueLimit < 1) throw new IllegalArgumentException("invalid transmitter settings");
        this.advertiseMode = advertiseMode; this.txPower = txPower; this.includeDeviceName = includeDeviceName;
        this.tickMs = tickMs; this.idleMs = idleMs; this.queueLimit = queueLimit;
    }
    public boolean isRunning() { return running; }

    public void start() {
        if (running) return;
        if (Build.VERSION.SDK_INT >= 31 && context.checkSelfPermission(android.Manifest.permission.BLUETOOTH_ADVERTISE) != PackageManager.PERMISSION_GRANTED)
            throw new IllegalStateException("BLUETOOTH_ADVERTISE permission not granted");
        BluetoothManager bm = (BluetoothManager) context.getSystemService(Context.BLUETOOTH_SERVICE);
        BluetoothAdapter a = bm == null ? null : bm.getAdapter();
        if (a == null || !a.isEnabled()) throw new IllegalStateException("Bluetooth is unavailable or disabled");
        advertiser = a.getBluetoothLeAdvertiser();
        if (advertiser == null) throw new IllegalStateException("BLE advertising is not supported on this device");
        running = true; idleSent = false; lastCommandAt = System.currentTimeMillis();
        handler.post(tick);
    }

    public void send(String uuid) {
        if (!running) throw new IllegalStateException("Transmitter not started");
        synchronized (queue) { while (queue.size() >= queueLimit) queue.poll(); queue.offer(uuid); }
        lastCommandAt = System.currentTimeMillis(); idleSent = false;
    }

    private void startFrame(final String value) {
        if (advertiser == null) return;
        try {
            if (callback != null) advertiser.stopAdvertising(callback);
            AdvertiseSettings settings = new AdvertiseSettings.Builder()
                .setAdvertiseMode(advertiseMode).setTxPowerLevel(txPower).setConnectable(false).build();
            AdvertiseData data = new AdvertiseData.Builder()
                .setIncludeDeviceName(includeDeviceName).addServiceUuid(new ParcelUuid(UUID.fromString(value))).build();
            callback = new AdvertiseCallback() {
                @Override public void onStartFailure(int errorCode) {
                    if (failureListener != null) failureListener.onFailure(errorCode, describe(errorCode));
                }
            };
            advertiser.startAdvertising(settings, data, callback);
        } catch (RuntimeException e) {
            if (failureListener != null) failureListener.onFailure(-1, String.valueOf(e.getMessage()));
        }
    }

    private static String describe(int code) {
        switch (code) {
            case AdvertiseCallback.ADVERTISE_FAILED_DATA_TOO_LARGE: return "Advertise data too large (turn off 'Include device name')";
            case AdvertiseCallback.ADVERTISE_FAILED_TOO_MANY_ADVERTISERS: return "Too many advertisers";
            case AdvertiseCallback.ADVERTISE_FAILED_ALREADY_STARTED: return "Already advertising";
            case AdvertiseCallback.ADVERTISE_FAILED_INTERNAL_ERROR: return "Internal advertise error";
            case AdvertiseCallback.ADVERTISE_FAILED_FEATURE_UNSUPPORTED: return "Advertising feature unsupported";
            default: return "Advertise failed, code " + code;
        }
    }

    public void stop() {
        running = false; handler.removeCallbacks(tick);
        try { if (advertiser != null && callback != null) advertiser.stopAdvertising(callback); } catch (RuntimeException ignored) {}
        callback = null;
        synchronized (queue) { queue.clear(); }
    }
}
