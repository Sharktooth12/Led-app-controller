import com.example.colbor.protocol.ColborProtocol;
import com.example.colbor.protocol.Target;

/** Standalone regression tests for the handoff's fixed-random-byte vectors. */
public final class OracleTest {
    private static void eq(String name,String expected,String actual){if(!expected.equals(actual))throw new AssertionError(name+"\nexpected: "+expected+"\nactual:   "+actual);System.out.println("PASS "+name);}
    public static void main(String[] args){ColborProtocol p=new ColborProtocol(0xA5);
        eq("power on all", "00000000-0201-02FF-FF33-83A500000A1E",p.power(Target.all(),0,true));
        eq("brightness all", "00000001-F406-02FF-FF33-83A500000B1E",p.brightness(Target.all(),0,50));
        eq("CCT 5600 all", "00000015-E003-02FF-FF33-83A500000B1E",p.cct(Target.all(),0,5600));
        eq("brightness single", "00000001-F406-02AB-1233-03A500000B1E",p.brightness(Target.single(0xAB12),0,50));
        eq("brightness group", "00000001-F406-0200-0733-83A500000B1E",p.brightness(Target.group(7),0,50));
        eq("join all", "00000000-1234-01FF-FF13-83A500000A1E",p.join(Target.all(),0x1234,false));
        eq("join single", "00000000-1234-01AB-1213-03A500000A1E",p.join(Target.single(0xAB12),0x1234,false));
        eq("effect params reversed", "00000002-0302-02FF-FF33-83A500000C1E",p.effect(Target.all(),0,3,2,0));
        eq("leave single", "00000000-0000-02AB-1213-03A50000081E",p.leave(Target.single(0xAB12),0));
        String fmt="[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}";
        String[] all={p.hsi(Target.all(),0,100,100,360),p.gm(Target.all(),0,255),p.group(Target.all(),0,7,true),p.cctBrightness(Target.all(),0,100,9000),p.rawControl(Target.all(),0,"01F4","0602")};
        for(String u:all) if(!u.matches(fmt)) throw new AssertionError("bad UUID format: "+u);
        System.out.println("PASS uuid format");
        eq("raw == brightness", p.brightness(Target.all(),0,50), p.rawControl(Target.all(),0,"01F4","0602"));
        try{p.brightness(Target.all(),0,101);throw new AssertionError("no range check");}catch(IllegalArgumentException ok){System.out.println("PASS range check");}
        try{p.leave(Target.all(),0);throw new AssertionError("leave accepted ALL");}catch(IllegalArgumentException ok){System.out.println("PASS leave needs SINGLE");}
    }
}
